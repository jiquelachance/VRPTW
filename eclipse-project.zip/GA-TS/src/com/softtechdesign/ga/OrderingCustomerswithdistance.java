package com.softtechdesign.ga;

import java.util.ArrayList;
import java.util.Comparator;

import com.mdvrp.Customer;
import com.mdvrp.Depot;
import com.mdvrp.Instance;

public class OrderingCustomerswithdistance implements Comparator {

	public double[][] distances;
	private ArrayList<Depot> depots = new ArrayList<>();
	public Instance inst;

	public OrderingCustomerswithdistance(Instance instance, double[][] distances, ArrayList<Depot> depots){
		this.distances=distances;
		this.depots=depots;
		this.inst=instance;
	}

	public int compare(Object a, Object b) {

		Customer acust= (Customer) a; 
		Customer bcust= (Customer) b;
		int anum=acust.getNumber();
		int bnum=bcust.getNumber();

		System.out.println("Customer " + acust.getNumber() + " X: " + acust.getXCoordinate());
		System.out.println("Customer " + acust.getNumber() + " Y: " + acust.getYCoordinate());
		System.out.println("Customer " + bcust.getNumber() + " X: " + bcust.getXCoordinate());
		System.out.println("Customer " + bcust.getNumber() + " Y: " + bcust.getYCoordinate());
		
		System.out.println("Depot X:" + depots.get(0).getXCoordinate());
		System.out.println("Depot Y:" + depots.get(0).getYCoordinate());
		
		if (   ( Math.sqrt(Math.pow( Math.abs(acust.getXCoordinate() - depots.get(0).getXCoordinate()), 2)
				+ Math.pow( Math.abs(acust.getYCoordinate() - depots.get(0).getYCoordinate()), 2)) )
				>=
				(Math.sqrt(Math.pow( Math.abs(bcust.getXCoordinate() - depots.get(0).getXCoordinate()), 2)
						+ Math.pow( Math.abs(bcust.getYCoordinate() - depots.get(0).getYCoordinate()), 2))
						)
				)
		{
			System.out.println("Customer " + acust.getNumber() + " is farer than " + bcust.getNumber());
			return -1;
		}
		
		else 
			{
			System.out.println("Customer " + acust.getNumber() + " is nearer than " + bcust.getNumber());
			return 1;
			}
	}

}
