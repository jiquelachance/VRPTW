package com.softtechdesign.ga;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.TabuSearch.MyMoveManager;
import com.TabuSearch.MyObjectiveFunction;
import com.TabuSearch.MySearchProgram;
import com.TabuSearch.MySolution;
import com.TabuSearch.MyTabuList;
import com.mdvrp.Customer;
import com.mdvrp.Depot;
import com.mdvrp.Instance;
import com.mdvrp.Parameters;
import com.sun.deploy.uitoolkit.impl.fx.FXWindowFactory;

public class MyGA extends GA {

	private ArrayList<Customer> customers;
	private Instance instance;
	private MyObjectiveFunction objF;
	private Parameters parameters;
	private MySearchProgram search;
	private int nrRoutesminimum = 100000000; //a big number
	private double feasiblecosttotalminimum = 100000000; //a big number
	private double feasiblecosttotalsecondminimum = 11111111;
	private MySolution bestsol;
	private MySolution secondbestsol;
	private int bestTsChromIndex;
	private int notimprovingcycles=0; //this is the number of cycles where best solution is not improved
	private int samebestsolutioncycles=0; //this is the number of cycles where i ts returns me always the same solution that corresponds to the best found
	public MyGA(int chromosomeDim, int populationDim, double crossoverProb,
			int randomSelectionChance, int maxGenerations, int numPrelimRuns,
			int maxPrelimGenerations, double mutationProb, int crossoverType,
			boolean computeStatistics, Instance instance, MyObjectiveFunction objF,
			Parameters parameters) {


		super(chromosomeDim, populationDim, crossoverProb, randomSelectionChance,
				maxGenerations, numPrelimRuns, maxPrelimGenerations, mutationProb,
				crossoverType, computeStatistics);

		//create the chromosomes for this population
		for (int i = 0; i < populationDim; i++)
		{
			this.chromosomes[i] = new MyChromosome(chromosomeDim);
			this.chromNextGen[i] = new MyChromosome(chromosomeDim);
			this.prelimChrom[i] = new MyChromosome(chromosomeDim);
		}

		this.instance=instance;
		this.customers=instance.getCustomers();
		this.objF=objF;
		this.parameters=parameters;
		initPopulation();
	}

	@Override
	protected void initPopulation() {
		ArrayList<Customer> temp=new ArrayList<>();
		temp.addAll(customers);

		instance.calculateDistances();

		ArrayList<Customer> temp2=new ArrayList<>();
		temp2.addAll(customers);
		ArrayList<Customer> orderedwithdistance=new ArrayList<>();
		Customer customeractual = new Customer();
		int iterations=temp2.size();
		for(int j=0; j<iterations; j++){
			int flag=0;
			double distanceminimum=100000;
			double distanceactual;
			for(int i=0; i<temp2.size(); i++){
				customeractual=temp2.get(i);
				distanceactual= (Math.sqrt(Math.pow( Math.abs(customeractual.getXCoordinate() - instance.depots.get(0).getXCoordinate()), 2)
						+ Math.pow( Math.abs(customeractual.getYCoordinate() - instance.depots.get(0).getYCoordinate()), 2)) );
				if(distanceactual<distanceminimum){
					flag=i;
					distanceminimum=distanceactual;
				}
			}
			System.out.println("Customer " + flag + " con x=" + temp2.get(flag).getXCoordinate() + "e y=" + temp2.get(flag).getYCoordinate() + " ha distanza " + distanceminimum + " dal depot con x=" + instance.depots.get(0).getXCoordinate() + " e y=" + instance.depots.get(0).getYCoordinate());
			orderedwithdistance.add(temp2.get(flag));
			temp2.remove(flag);
		}


		for (int i = 0; i < populationDim; i++){

			if(i<populationDim/3){

				//Collections.sort( temp, new OrderingCustomerswithdistance(instance, instance.distances, instance.depots) );

				for (int iGene = 0; iGene < chromosomeDim; iGene++)
					((MyChromosome) this.chromosomes[i]).genes[iGene] = 
					orderedwithdistance.get(iGene);
			}

			else{
				Collections.shuffle(temp);
				for (int iGene = 0; iGene < chromosomeDim; iGene++)
					((MyChromosome) this.chromosomes[i]).genes[iGene] = temp.get(iGene);
			}
		}



	}

	@Override
	protected void doRandomMutation(int iChromIndex) {
		int iGene1, iGene2;
		Customer cTemp;

		for(int i=0; i<populationDim/10; i++){
			iGene1 = getRandom(chromosomeDim);
			iGene2 = getRandom(chromosomeDim);

			cTemp = ((MyChromosome) this.chromosomes[iChromIndex]).genes[iGene1];
			((MyChromosome) this.chromosomes[iChromIndex]).genes[iGene1] =
					((MyChromosome) this.chromosomes[iChromIndex]).genes[iGene2];
			((MyChromosome) this.chromosomes[iChromIndex]).genes[iGene2] = cTemp;
		}

	}

	@Override
	protected void doOnePtCrossover(Chromosome Chrom1, Chromosome Chrom2) {
		MyChromosome newChrom1= (MyChromosome)Chrom1;
		MyChromosome newChrom2= (MyChromosome)Chrom2;

		int iCrossoverPoint;

		iCrossoverPoint = getRandom(chromosomeDim - (chromosomeDim*30)/100);

		for(int j=0; j<iCrossoverPoint; j++){
			((MyChromosome)Chrom1).genes[j]=newChrom1.genes[j];
			((MyChromosome)Chrom2).genes[j]=newChrom2.genes[j];		
		}

		int i=0;
		int cp=iCrossoverPoint;
		int insertChild=iCrossoverPoint;
		while(i<chromosomeDim){

			if(((MyChromosome)Chrom2).getPartialPosition(newChrom1.genes[cp], iCrossoverPoint)==-1){
				((MyChromosome)Chrom2).genes[insertChild]=newChrom1.genes[cp];
				insertChild++;
			}
			cp++;
			i++;

			if(cp==chromosomeDim)
				cp=0;
		}

		i=0;
		cp=iCrossoverPoint;
		insertChild=iCrossoverPoint;
		while(i<chromosomeDim){

			if(((MyChromosome)Chrom1).getPartialPosition(newChrom2.genes[cp], iCrossoverPoint)==-1){
				((MyChromosome)Chrom1).genes[insertChild]=newChrom2.genes[cp];
				insertChild++;
			}

			cp++;
			i++;

			if(cp==chromosomeDim)
				cp=0;
		}

		System.out.println("OnePointCrossover ch1: "+ ((MyChromosome)Chrom1).toString());
		System.out.println("OnePointCrossover ch2: "+ ((MyChromosome)Chrom2).toString());
	}

	@Override
	protected void doTwoPtCrossover(Chromosome Chrom1, Chromosome Chrom2) {
		/*MyChromosome newChrom1= (MyChromosome)Chrom1;
		MyChromosome newChrom2= (MyChromosome)Chrom2;

		int iCrossoverPoint1, iCrossoverPoint2;

		 iCrossoverPoint1 = (chromosomeDim*10)/100 + getRandom(chromosomeDim - (chromosomeDim*30)/100);
	     iCrossoverPoint2 = iCrossoverPoint1 + (chromosomeDim*10)/100 + getRandom(chromosomeDim - iCrossoverPoint1 - (chromosomeDim*30)/100);

		for(int j=0; j<iCrossoverPoint1; j++){
			((MyChromosome)Chrom1).genes[j]=newChrom1.genes[j];
			((MyChromosome)Chrom2).genes[j]=newChrom2.genes[j];		
		}

		for(int i=iCrossoverPoint1; i<iCrossoverPoint2; i++){
			((MyChromosome)Chrom1).genes[i]=newChrom2.genes[i];
			((MyChromosome)Chrom2).genes[i]=newChrom1.genes[i];
		}

		for(int i=iCrossoverPoint2; i<chromosomeDim; i++){
			((MyChromosome)Chrom1).genes[i]=newChrom1.genes[i];
			((MyChromosome)Chrom2).genes[i]=newChrom2.genes[i];
		}*/

	}

	protected void doHeuristicCrossover(Chromosome child1, Chromosome child2) {
		MyChromosome par1 = new MyChromosome(((MyChromosome)child1).genes.length);
		par1.copyChromGenes(child1);
		MyChromosome par2 = new MyChromosome(((MyChromosome)child2).genes.length);
		par2.copyChromGenes(child2);

		int countPar1 = 0;
		int countPar2 = 0;

		int cutPoint = getRandom(chromosomeDim - (chromosomeDim*30)/100) + chromosomeDim*20/100;
		int nextCutPoint=cutPoint+1;
		//int pairIndex=0;

		((MyChromosome)child1).genes[0]=par1.genes[cutPoint];

		int posFirst=par2.getPosition(par1.genes[cutPoint]);
		par2.swapGenes(posFirst, cutPoint);

		for(int i=1; i<par1.genes.length; i++){

			if(cutPoint>=par1.genes.length){
				cutPoint=0;
			}

			if(nextCutPoint>=par1.genes.length)
				nextCutPoint=0;

			double d1=instance.getTravelTime(par1.genes[cutPoint].getNumber(), 
					par1.genes[nextCutPoint].getNumber());
			double d2=instance.getTravelTime(par2.genes[cutPoint].getNumber(), 
					par2.genes[nextCutPoint].getNumber());

			if(d1>d2){
				countPar1++;
				((MyChromosome)child1).genes[i]=par2.genes[nextCutPoint];
				int pos=par1.getPosition(par2.genes[nextCutPoint]);
				par1.swapGenes(nextCutPoint, pos);
			}
			else{
				countPar2++;
				((MyChromosome)child1).genes[i]=par1.genes[nextCutPoint];
				int pos=par2.getPosition(par1.genes[nextCutPoint]);
				par2.swapGenes(nextCutPoint, pos);
			}
			cutPoint++;
			nextCutPoint++;
		}
		if(countPar1<=countPar2)
			child2.copyChromGenes(par1);
		else
			child2.copyChromGenes(par2);

		if(checkForDuplicates((MyChromosome) child1))System.err.println("duplicates in child1");
		if(checkForDuplicates((MyChromosome) child2))System.err.println("duplicates in child2");
	}

	/** Heurist Crossover
	 * 
	 * 	This operator is concerned with distances between nodes. In the following
		example, a random cut is made on two chromosomes and we look at the two 
		genes b and g immediately after the cut points.

		Parent 1: h k e f d   b l a i g j
		Parent 2: a b d e f   g h i j k l

		One of them say b is picked to be the first gene in the child, 
		and other other gene g has to be swapped away with b in Parent 2 
		to avoid repetition subsequently. After swapping, we have this:

		Parent 1: h k e f d   b l a i g j
		Parent 2: a g d e f   b h i j k l
		Now we compare the physical distance between node b and l, dbl , 
		and the distance between b and h,dbh. 
		If dbl > dbh, we then choose h to be the next node 
		and swap l and h in the first parent. 
		This process is continued until a new chromosome of the same
		length is formed.
	 */

	protected void doPMXCrossover(MyChromosome child1, MyChromosome child2){
		System.out.println("PMX CROSSOVER");
		//if(checkForDuplicates((MyChromosome) child1))System.err.println("duplicates in child1");
		//if(checkForDuplicates((MyChromosome) child2))System.err.println("duplicates in child2");
		int cut1 = getRandom(chromosomeDim - (chromosomeDim*70)/100)+(chromosomeDim*10)/100;
		int cut2 = getRandom(chromosomeDim - (chromosomeDim*70)/100) + (chromosomeDim*60)/100;
		MyChromosome par1 = new MyChromosome(child1.genes.length);
		par1.copyChromGenes(child1);
		MyChromosome par2 = new MyChromosome(child2.genes.length);
		par2.copyChromGenes(child2);

		for(int i=cut1; i<cut2; i++){
			int p1 = child1.getPosition(par2.genes[i]);
			//if(p1>-1)
			child1.swapGenes(p1, i);

			int p2 = child2.getPosition(par1.genes[i]);
			//if(p2>-1)
			child2.swapGenes(p2, i);
		}

		if(checkForDuplicates((MyChromosome) child1)){
			System.err.println("duplicates after PMX in child1: "+child1.toString());

		}
		if(checkForDuplicates((MyChromosome) child2))System.err.println("duplicates after PMX in child2");

	}

	public boolean checkForDuplicates(MyChromosome ch){
		for(int i=0; i<ch.genes.length; i++){
			for(int j=0; j<ch.genes.length; j++){
				if(ch.genes[i].getNumber()==ch.genes[j].getNumber() && i!=j )return true;
			}
		}
		return false;
	}

	//Encoding a Chromosome to a Solution for TS
	public MySolution ChromosomeToSolution(Chromosome ch){
		return new MySolution(instance, (MyChromosome)ch);
	}

	@Override
	protected double getFitness(int iChromIndex) {
		MyChromosome ch = (MyChromosome) chromosomes[iChromIndex];
		MySolution sol=this.ChromosomeToSolution(ch);
		objF.evaluateAbsolutely(sol);
		return sol.getCost().travelTime;

	}


	public int evolve(){
		int iGen;
		int iPrelimChrom, iPrelimChromToUsePerRun;

		double secInizio=System.currentTimeMillis()/1000;

		if (numPrelimRuns > 0)
		{
			iPrelimChrom = 0;
			//number of fittest prelim chromosomes to use with final run
			iPrelimChromToUsePerRun = populationDim / numPrelimRuns;

			for (int iPrelimRuns = 1; iPrelimRuns <= numPrelimRuns; iPrelimRuns++)
			{
				iGen = 0;
				initPopulation();

				//create a somewhat fit chromosome population for this prelim run
				while (iGen < maxPrelimGenerations)
				{

					System.out.println(iPrelimRuns + " of " + numPrelimRuns + " prelim runs --> " +
							(iGen + 1) + " of " + maxPrelimGenerations + " generations");

					computeFitnessRankings();
					doGeneticMating();
					copyNextGenToThisGen();

					if (computeStatistics == true)
					{
						this.genAvgDeviation[iGen] = getAvgDeviationAmongChroms();
						this.genAvgFitness[iGen] = getAvgFitness();
					}


					iGen++;
				}

				computeFitnessRankings();

				//copy these somewhat fit chromosomes to the main chromosome pool
				int iNumPrelimSaved = 0;
				for (int i = 0; i < populationDim && iNumPrelimSaved < iPrelimChromToUsePerRun; i++)
					if (this.chromosomes[i].fitnessRank >= populationDim - iPrelimChromToUsePerRun)
					{
						this.prelimChrom[iPrelimChrom + iNumPrelimSaved].copyChromGenes(this.chromosomes[i]);
						//store (remember) these fit chroms
						iNumPrelimSaved++;
					}
				iPrelimChrom += iNumPrelimSaved;
			}
			for (int i = 0; i < iPrelimChrom; i++)
				this.chromosomes[i].copyChromGenes(this.prelimChrom[i]);
			System.out.println("INITIAL POPULATION AFTER PRELIM RUNS:");
		}
		else
			System.out.println("INITIAL POPULATION (NO PRELIM RUNS):");

		//Add Preliminary Chromosomes to list box
		addChromosomesToLog(0, populationDim);

		iGen = 0;

		while (iGen < maxGenerations)
		{
			if(samebestsolutioncycles == maxGenerations/5)
				break; //finish

			System.out.println("GA Cycle number: " + (iGen+1));

			addChromosomesToLog(iGen, populationDim);

			computeFitnessRankings();
			doGeneticMating();
			copyNextGenToThisGen(secInizio);

			if(iGen % 3 == 0){
				if(iGen == 0) parameters.setIterations(700);
				else parameters.setIterations(700);
				System.out.println("TS number 1 of cycle: " + (iGen+1));

				if(iGen % 6 == 0){
					startTS(ChromosomeToSolution(
							this.chromosomes[this.bestFitnessChromIndex]),this.bestFitnessChromIndex, secInizio, "FROM TS BESTFITNESS");


					System.out.println("TS number 2 of cycle: " + (iGen+1));
				}
				/*startTS(ChromosomeToSolution(
						this.chromosomes[getRandom(populationDim)]),getRandom(populationDim), secInizio);
				 */

				startTS(bestsol, 1, secInizio, "FROM TS BESTSOL");


				int iterations = parameters.getIterations();

				if(notimprovingcycles > maxGenerations/10){
					System.out.println("Entering intensive TS at GA cycle: " + iGen);
					parameters.setIterations(3000);
					startTS(bestsol, 1, secInizio, "FROM INTENSIVE TS");
					//initPopulation();
					System.out.println("Exiting intensive TS at GA cycle: " + iGen);
				}
				parameters.setIterations(iterations);
			}

			System.out.println("Current best solution cost: " + feasiblecosttotalminimum);


			if (computeStatistics == true)
			{
				this.genAvgDeviation[iGen] = getAvgDeviationAmongChroms();
				this.genAvgFitness[iGen] = getAvgFitness();
			}

			computeFitnessRankings();
			System.out.println("Best Chromosome Found: ");
			System.out.println(this.chromosomes[this.bestFitnessChromIndex].getGenesAsStr() +
					" Fitness= " + this.chromosomes[this.bestFitnessChromIndex].fitness);

			iGen++;
			this.mutationProb+=0.015;
			this.crossoverProb-=0.015;

			double currentSeconds=System.currentTimeMillis()/1000;
			if(currentSeconds - secInizio  >= 295){ //295 seconds are 4 minutes and 55 
				System.out.println("Entrato al ciclo n: "+ iGen);
				break;
			}

		}


		System.out.println("GEN " + (iGen + 1) + " AVG FITNESS = " + this.genAvgFitness[iGen-1] +
				" AVG DEV = " + this.genAvgDeviation[iGen-1]);

		addChromosomesToLog(iGen, populationDim); //display Chromosomes to system.out

		computeFitnessRankings();
		System.out.println("Best Chromosome Found: ");
		System.out.println(this.chromosomes[this.bestFitnessChromIndex].getGenesAsStr() +
				" Fitness= " + this.chromosomes[this.bestFitnessChromIndex].fitness);


		double currentSeconds=System.currentTimeMillis()/1000;

		/*
		String outSol = String.format("%s; %5.2f; %4d; %d; %f\r" ,
				instance.getParameters().getInputFileName(), 
				feasiblecosttotalminimum, 
				nrRoutesminimum, iGen, (currentSeconds - secInizio) );
		*/
		String outSol = String.format("%s; %5.2f; %3d; %3.2f\r" ,
				instance.getParameters().getInputFileName(), 
				feasiblecosttotalminimum, 
				nrRoutesminimum, (currentSeconds - secInizio) );

		System.out.println("File: " + instance.getParameters().getInputFileName()+ 
				"\n"+ "Minimum cost: " + feasiblecosttotalminimum+
				"\n"+ "Vehicles number: "+ nrRoutesminimum);

		System.out.println("Best solution fitness: " + bestsol.SolutionToChromosome().getFitness(instance, objF));


		System.out.println("Tempo totale:" + (currentSeconds - secInizio));
		System.out.println("Numero cicli di GA:" + iGen);

		try{
			FileWriter fw = new FileWriter(parameters.getOutputFileName(),true);
			fw.write(outSol);
			fw.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return (iGen);
	}

	private double evaluateFitness(MySolution sol, int index, double seconds, MySearchProgram search){

		// Init memory for Tabu Search

		MyMoveManager moveManager 	= new MyMoveManager(instance);
		moveManager.setMovesType(parameters.getMovesType());

		// Tabu list
		int dimension[] = {instance.getDepotsNr(), instance.getVehiclesNr(), instance.getCustomersNr(), 1, 1};
		MyTabuList tabuList 		= new MyTabuList(parameters.getTabuTenure(), dimension);


		// Create Tabu Search object
		search = new MySearchProgram(parameters, instance, 
				sol, 
				moveManager,
				objF, tabuList, false,  null, seconds, feasiblecosttotalminimum);

		// Start solving        
		search.tabuSearch.setIterationsToGo(5);

		search.tabuSearch.startSolving();

		// wait for the search thread to finish
		try {
			// in order to apply wait on an object synchronization must be done
			synchronized(instance){
				instance.wait();
			}
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		if(search.feasibleCost.total==Double.POSITIVE_INFINITY)
			return ((MySolution)search.tabuSearch.getBestSolution()).getCost().total;

		else
			return search.feasibleCost.total;
	}

	private void startTS(MySolution sol, int index, double seconds, String message) {

		// Init memory for Tabu Search

		MyMoveManager moveManager 	= new MyMoveManager(instance);
		moveManager.setMovesType(parameters.getMovesType());

		// Tabu list
		int dimension[] = {instance.getDepotsNr(), instance.getVehiclesNr(), instance.getCustomersNr(), 1, 1};
		MyTabuList tabuList 		= new MyTabuList(parameters.getTabuTenure(), dimension);


		// Create Tabu Search object
		this.search = new MySearchProgram(parameters, instance, 
				sol, 
				moveManager,
				objF, tabuList, false,  null, seconds, feasiblecosttotalminimum);

		// Start solving        
		search.tabuSearch.setIterationsToGo(parameters.getIterations());

		search.tabuSearch.startSolving();

		// wait for the search thread to finish
		try {
			// in order to apply wait on an object synchronization must be done
			synchronized(instance){
				instance.wait();
			}
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}


		this.chromosomes[index].copyChromGenes(
				((MySolution)search.tabuSearch.getBestSolution()).SolutionToChromosome());

		if( Math.floor(feasiblecosttotalminimum) >= Math.floor(search.feasibleCost.total))
			samebestsolutioncycles++;
		else samebestsolutioncycles=0;

		if(feasiblecosttotalsecondminimum > search.feasibleCost.total && feasiblecosttotalminimum < search.feasibleCost.total){
			feasiblecosttotalsecondminimum = search.feasibleCost.total;
			secondbestsol = (MySolution)search.tabuSearch.getBestSolution();
		}

		//saving all results from TS if it is the best
		if(feasiblecosttotalminimum > search.feasibleCost.total)
		{
			feasiblecosttotalsecondminimum = feasiblecosttotalminimum;
			feasiblecosttotalminimum = search.feasibleCost.total;
			bestsol = (MySolution)search.tabuSearch.getBestSolution();
			notimprovingcycles=0;
			System.out.println("BETTER SOLUTION FOUND " + message + " !");

			for(int i=0; i<((MySolution)search.tabuSearch.getBestSolution()).getRoutes()[0].length; i++)

				for(int j=0; j< ((MySolution)search.tabuSearch.getBestSolution()).getRoutes()[0][i].getCustomersLength(); j++)
					System.out.print( ((MySolution)search.tabuSearch.getBestSolution()).getRoutes()[0][i].getCustomerNr(j) + " ");


			// Count routes
			int routesNr = 0;
			for(int l =0; l < search.feasibleRoutes.length; ++l)
				for(int m=0; m < search.feasibleRoutes[l].length; ++m)
					if(search.feasibleRoutes[l][m].getCustomersLength() > 0)
						routesNr++;	

			nrRoutesminimum = routesNr;
		}
		else notimprovingcycles++;

	}

	/**
	 * Copy the chromosomes previously created and stored in the "next" generation into the main
	 * chromsosome memory pool. Perform random mutations where appropriate.
	 */
	void copyNextGenToThisGen(double seconds)
	{
		for (int i = 0; i < populationDim; i++)
		{
			this.chromosomes[i].copyChromGenes(this.chromNextGen[i]);

			//only mutate chromosomes if it is NOT the best
			if (i != this.bestFitnessChromIndex)
			{
				//always mutate the chromosome with the lowest fitness
				if ((getRandom(1.0) < mutationProb)){
					doRandomMutation(i);
					//				if(getRandom(1.0)>0.75){
					startTS(ChromosomeToSolution(this.chromosomes[i]),i, seconds, "FROM TS MUTATION");
					this.chromosomes[i].copyChromGenes(
							((MySolution)search.tabuSearch.getBestSolution()).SolutionToChromosome());
					//				}
				}
			}
		}
	}

	@Override
	/**
	 * Create the next generation of chromosomes by genetically mating fitter individuals of the
	 * current generation.
	 * Also employ elitism (so the fittest 2 chromosomes always survive to the next generation). 
	 * This way an extremely fit chromosome is never lost from our chromosome pool.
	 */
	void doGeneticMating()
	{
		int iCnt, iRandom;
		int indexParent1 = -1, indexParent2 = -1;
		Chromosome Chrom1, Chrom2;

		iCnt = 0;

		this.chromNextGen[iCnt].copyChromGenes(this.chromosomes[this.bestFitnessChromIndex]);
		iCnt++;
		this.chromNextGen[iCnt].copyChromGenes(this.chromosomes[2]);
		iCnt++;
		this.chromNextGen[iCnt].copyChromGenes(this.chromosomes[3]);
		iCnt++;
		this.chromNextGen[iCnt].copyChromGenes(this.chromosomes[4]);
		iCnt++;
		this.chromNextGen[iCnt].copyChromGenes(this.chromosomes[5]);
		iCnt++;
		this.chromNextGen[iCnt].copyChromGenes(this.chromosomes[1]); //the chromosome returned by TS is put in the position 1 of the nextgen
		iCnt++;


		Chrom1 = new MyChromosome(chromosomeDim);
		Chrom2 = new MyChromosome(chromosomeDim);

		do{
			int indexes[] = { indexParent1, indexParent2 };
			selectTwoParents(indexes);
			indexParent1 = indexes[0];
			indexParent2 = indexes[1];

			Chrom1.copyChromGenes(this.chromosomes[indexParent1]);
			Chrom2.copyChromGenes(this.chromosomes[indexParent2]);

			if(Chrom1.equals(Chrom2)){
				this.doRandomMutation(indexParent1);
			}

			if (getRandom(1.0) < crossoverProb) //do crossover
			{
				if (this.crossoverType == Crossover.ctOnePoint)
					doOnePtCrossover(Chrom1, Chrom2);
				else if (this.crossoverType == Crossover.ctTwoPoint)
					doTwoPtCrossover(Chrom1, Chrom2);
				else if (this.crossoverType == Crossover.ctHeuristic)
					doHeuristicCrossover(Chrom1, Chrom2);
				else if (this.crossoverType == Crossover.ctPMX)
					doPMXCrossover((MyChromosome)Chrom1, (MyChromosome)Chrom2);
				else if (this.crossoverType == Crossover.ctRoulette)
				{
					iRandom = getRandom(3);
					if (iRandom < 1)
						doOnePtCrossover(Chrom1, Chrom2);
					else if (iRandom < 2)
						doTwoPtCrossover(Chrom1, Chrom2);
					else
						doUniformCrossover(Chrom1, Chrom2);
				}

				/* TS eseguito su un figlio ogni crossover
				startTS(ChromosomeToSolution(Chrom1));

				this.chromNextGen[iCnt].copyChromGenes(
						((MySolution)search.tabuSearch.getBestSolution()).SolutionToChromosome());*/
				this.chromNextGen[iCnt].copyChromGenes(Chrom1);
				iCnt++;
				this.chromNextGen[iCnt].copyChromGenes(Chrom2);
				iCnt++;
			}
			else //if no crossover, then copy this parent chromosome "as is" into the offspring
			{
				// CREATE OFFSPRING ONE
				this.chromNextGen[iCnt].copyChromGenes(Chrom1);
				iCnt++;

				// CREATE OFFSPRING TWO
				this.chromNextGen[iCnt].copyChromGenes(Chrom2);
				iCnt++;
			}
		}
		while (iCnt < populationDim);
	}


	public void reordering_distances(){
		instance.calculateDistances();
	}

	@Override
	protected void doUniformCrossover(Chromosome Chrom1, Chromosome Chrom2) {
		// TODO Auto-generated method stub

	}

}
