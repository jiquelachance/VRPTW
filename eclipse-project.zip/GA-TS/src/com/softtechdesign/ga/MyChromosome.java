package com.softtechdesign.ga;
import com.TabuSearch.MyObjectiveFunction;
import com.TabuSearch.MySolution;
import com.mdvrp.Customer;
import com.mdvrp.Instance;

public class MyChromosome extends Chromosome{

	public Customer [] genes;

	public MyChromosome(int chromosomeDim){
		this.genes=new Customer[chromosomeDim];
	}

	@Override
	String getGenesAsStr() {

		String s="";

		for(int i=0; i<genes.length; i++){
			s = s+ genes[i].getNumber()+" ";
		};

		return s;
	}

	@Override
	void copyChromGenes(Chromosome genes) {
		MyChromosome c= (MyChromosome) genes;
		for(int i=0; i<c.genes.length; i++)
			this.genes[i]=c.genes[i];

	}

	@Override
	int getNumGenesInCommon(Chromosome genes) {
		MyChromosome c= (MyChromosome) genes;
		int cont=0;
		for(int i=0; i<c.genes.length; i++){
			for(int j=0; j<this.genes.length; j++){
				if(c.genes[i].getNumber()==this.genes[j].getNumber())
					cont++;
			}
		}

		return cont;
	}

	public int getPosition(Customer customer){
		for(int i=0; i<this.genes.length; i++){
			if(customer.getNumber()==this.genes[i].getNumber())
				return i;
		}

		return -1;
	}

	public int getPartialPosition(Customer customer, int finalPosition){
		for(int i=0; i<finalPosition; i++){
			if(customer.getNumber()==this.genes[i].getNumber())
				return i;
		}

		return -1;
	}

	public void swapGenes(int indGene1, int indGene2){
		Customer temp=this.genes[indGene1];
		this.genes[indGene1]=this.genes[indGene2];
		this.genes[indGene2]=temp;
	}

	public String toString(){
		return this.getGenesAsStr();
	}

	public Customer[] getGenes(){
		return genes;
	}

	public Customer getGene(int iGene)
	{
		return this.genes[iGene];
	}

	public void setGene(int iGene, Customer value){
		genes[iGene] = value;
	}

	public double getFitness(Instance instance, MyObjectiveFunction objF) {

		MySolution sol = new MySolution(instance, (MyChromosome)this);
		objF.evaluateAbsolutely(sol);
		return sol.getCost().travelTime;
	}

	int partition(int arr[], int left, int right, Instance instance)
	{
		  
		  int i = left, j = right;
	      int tmp;
	      int pivot = arr[(left + right) / 2];
	     
	      while (i <= j) {
	            while (instance.distances[0][arr[i]] < instance.distances[0][pivot])
	                  i++;
	            while (instance.distances[0][arr[j]] > instance.distances[0][pivot])
	                  j--;
	            if (i <= j) {
	                  tmp = arr[i];
	                  arr[i] = arr[j];
	                  arr[j] = tmp;
	                  i++;
	                  j--;
	            }
	      };
	     
	      return i;
	}

	int[] quickSort (int[] arr, int left, int right, Instance instance) {

		int index = partition(arr, left, right, instance);
		if (left < index - 1)
			quickSort(arr, left, index - 1, instance);
		if (index < right)
			quickSort(arr, index, right, instance);
		return arr;
	}

	public MyChromosome assigncustomers(int[] orderedarray, Instance instance) {
	
		MyChromosome orderedchromosome = new MyChromosome(instance.getCustomers().size());
		
		for(int i=0; i<orderedarray.length; i++){
			int custnum = orderedarray[i];
			orderedchromosome.genes[i] = instance.getCustomers().get(custnum);
		}
		return orderedchromosome;
	}
}
