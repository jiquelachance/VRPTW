﻿package com.mdvrp;

import com.TabuSearch.MyObjectiveFunction;
import com.softtechdesign.ga.Crossover;
import com.softtechdesign.ga.MyGA;

public class MDVRPTW {
		
	public static void main(String[] args) {
		MyObjectiveFunction objFunc;
		Parameters          parameters 		= new Parameters(); 	// holds all the parameters passed from the input line
		Instance            instance; 								// holds all the problem data extracted from the input file

		try {			
			// check to see if an input file was specified
			parameters.updateParameters(args);
			if(parameters.getInputFileName() == null){
				System.out.println("You must specify an input file name");
				return;
			}
			
			
			// get the instance from the file			
			instance = new Instance(parameters); 
			instance.populateFromHombergFile(parameters.getInputFileName());
						
			objFunc 		= new MyObjectiveFunction(instance);
			
	        //Avviamento GA
			
			MyGA ga= new MyGA(
					instance.getCustomersNr(),
					30,//populationDim
					1,//crossoverprob
					0,//randomselection% (probability of choosing not using fitness)
					36, //maxGen (number of iterations)
					0, //prelimRuns (number of preliminar execution of GA)
					0,
					0, //mutationProb
					Crossover.ctOnePoint, //crossoverType
					true, //computeStatistics
					instance,
					objFunc,
					parameters
					);
			
			ga.run();
			
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
